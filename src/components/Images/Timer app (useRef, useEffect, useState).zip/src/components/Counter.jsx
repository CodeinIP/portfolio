import { useEffect, useRef, useState } from "react";

export const Counter = () => {
  const [count, setCount] = useState(10);
  const countRef = useRef(null);
  useEffect(() => {
    // start();
    return () => {
      clearInterval(countRef.current);
    };
  }, []);
  const start = () => {
    if (countRef.current) {
      return;
    }
    countRef.current = setInterval(() => {
      setCount((count) => {
        if (count === 0) {
          console.log("stop");
          stop();
          return;
        } else {
          return count - 1;
        }
      });
    }, 1000);
  };
  const stop = () => {
    if (countRef.current == null) {
      console.log("returning");
      return;
    } else {
      console.log("clearing interval");
      clearInterval(countRef.current);
      setCount(10);
      countRef.current = null;
    }
  };
  const reset = () => {
    stop();
    setCount(10);
  };
  const sytle1 = {
    border: "none",
    background: "teal",
    padding: "5px 10px",
    color: "white",
    borderRadius: "5px",
    cursor: "pointer"
  };
  return (
    <div style={{ background: "lightblue", padding: "20px" }}>
      <h1 style={{ color: "gray" }}>Timer:{count}</h1>
      <div
        style={{
          background: "white",
          padding: "20px",
          display: "flex",
          justifyContent: "space-evenly"
        }}
      >
        <button style={sytle1} onClick={() => start()}>
          Start
        </button>
        <button style={sytle1} onClick={() => stop()}>
          Stop
        </button>
        <button style={sytle1} onClick={() => reset()}>
          Reset
        </button>
      </div>
    </div>
  );
};
