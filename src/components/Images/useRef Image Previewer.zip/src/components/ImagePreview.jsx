import { useRef, useState } from "react";

export const ImagePreview = () => {
  const [pic, setPic] = useState(null);
  const target = useRef(null);
  const handleImage = (e) => {
    let img = e.target.files[0];
    console.log(URL.createObjectURL(img));
    setPic(URL.createObjectURL(img));
  };
  return (
    <div className="page">
      {pic && (
        <img
          style={{ width: "300px", height: "250px", objectFit: "contain" }}
          src={pic}
          alt="profile"
        />
      )}
      <button onClick={() => target.current.click()}>Upload File</button>
      <hr />
      <input type="file" ref={target} onChange={(e) => handleImage(e)} />
    </div>
  );
};
