import { ImagePreview } from "./components/ImagePreview";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <ImagePreview />
    </div>
  );
}
